shopt -s cdspell dirspell

